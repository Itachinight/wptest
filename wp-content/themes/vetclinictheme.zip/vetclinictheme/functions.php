<?php  
register_nav_menus( array(
		'header_menu' => "Header Menu",
		'footer_menu' => "Footer Menu",
	) );
add_theme_support( 'post-thumbnails' );
add_theme_support( 'woocommerce' );
?>